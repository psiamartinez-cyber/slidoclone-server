# SlidoClone MVP — Guía de Despliegue

## Archivos del proyecto

```
slidoclone/
├── server/
│   ├── index.js        ← Servidor Node.js + Socket.io
│   ├── package.json    ← Dependencias
│   └── .gitignore
├── client/
│   └── index.html      ← Frontend completo (un solo archivo)
└── README.md
```

## Paso 1 — Servidor en Railway (gratis)

1. Ve a https://railway.app y crea cuenta con GitHub
2. Clic en "New Project" → "Deploy from GitHub repo"
3. Sube SOLO la carpeta `server/` a un repositorio GitHub
4. Railway detecta automáticamente Node.js
5. En "Variables" agrega: PORT = 3001 (opcional, Railway lo gestiona)
6. Copia la URL pública que Railway te da: https://TU-APP.up.railway.app

## Paso 2 — Editar el frontend

Abre `client/index.html` y busca la línea:

```javascript
const SERVER_URL = window.SERVER_URL || 'https://TU-APP.railway.app';
```

Reemplaza `https://TU-APP.railway.app` por tu URL real de Railway.

## Paso 3 — Frontend en Netlify (gratis)

1. Ve a https://app.netlify.com/drop
2. Arrastra el archivo `client/index.html` al área de drop
3. Netlify genera una URL tipo https://amazing-name-123.netlify.app
4. ¡Listo! Comparte esa URL con tus participantes

## Credenciales de prueba

- Admin: admin@slido.co / admin123
- Participantes: solo necesitan el código del evento

## Límites del plan gratuito

| Servicio | Límite gratuito | Suficiente para 100 personas |
|----------|-----------------|------------------------------|
| Railway  | 500 horas/mes   | ✅ Sí (un evento de 8h = 8h) |
| Netlify  | 100 GB transfer | ✅ Sí                        |

## Para cambiar las credenciales de admin

Edita `server/index.js`, línea ~50:
```javascript
if(email === 'admin@slido.co' && password === 'admin123') {
```
Cambia por tu email y contraseña reales.
